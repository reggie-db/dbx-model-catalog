import { fileURLToPath } from 'node:url';

const workspaceRoot = fileURLToPath(new URL('../../../..', import.meta.url));
const serverRoot = fileURLToPath(
  new URL('../../../../packages/py/server', import.meta.url),
);

export async function connectModelCatalog(url?: string) {
  const [{ createCatalogClient }, { startIpcServer }] = await Promise.all([
    import('@regbo/dbx-model-catalog-common'),
    import('pynect'),
  ]);
  const remoteUrl = url?.trim() || undefined;
  const server = remoteUrl
    ? undefined
    : await startIpcServer({ root: serverRoot });
  const client = createCatalogClient(
    remoteUrl ? { baseUrl: remoteUrl } : server!.clientOptions,
  );

  return {
    client,
    mode: remoteUrl ? 'remote' as const : 'ipc' as const,
    root: workspaceRoot,
    get pid(): number | undefined {
      return server?.pid;
    },
    async close(): Promise<void> {
      client.close();
      await server?.close();
    },
    async [Symbol.asyncDispose](): Promise<void> {
      await this.close();
    },
  };
}

export type * from '@regbo/dbx-model-catalog-common';
