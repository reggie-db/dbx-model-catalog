# dbx-model-catalog

Shared Pydantic models and local read/filter service for the Databricks model
catalog.

```py
from dbx_model_catalog import ModelCatalogClient

catalog = ModelCatalogClient.from_published()
models = catalog.list()
```

The package includes ordinary source-controlled Pydantic catalog models, JSON
and Brotli loading, and a serializable query DSL. The
published client caches the compressed normalized dataset for one hour in the
platform-native user cache directory; pass `refresh=True` to replace it.
