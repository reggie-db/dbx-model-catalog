from __future__ import annotations

from datetime import date
from enum import StrEnum
from typing import Annotated, Literal

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, confloat, conint, constr


class Type(StrEnum):
    """
    Normalized model type.
    """

    chat = 'chat'
    image = 'image'
    video = 'video'
    embedding = 'embedding'
    reranking = 'reranking'
    decision = 'decision'
    transcription = 'transcription'
    speech = 'speech'
    realtime = 'realtime'
    extraction = 'extraction'
    audio = 'audio'


class Status(StrEnum):
    """
    Current normalized lifecycle state.
    """

    active = 'active'
    preview = 'preview'
    alpha = 'alpha'
    beta = 'beta'
    legacy = 'legacy'
    deprecated = 'deprecated'
    retired = 'retired'


class Schedule(BaseModel):
    """
    Retirement dates for one serving offering.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    offering: str
    """
    Serving offering affected by this retirement schedule.
    """
    dates: list[date]
    """
    Retirement dates documented for the offering.
    """


class Retirement(BaseModel):
    """
    Databricks retirement and replacement information.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    schedules: list[Schedule]
    """
    Retirement schedules by serving offering.
    """
    replacement: constr(min_length=1) | None = None
    """
    Catalog key of the recommended replacement model when matched.
    """
    replacement_name: str | None = None
    """
    Documented replacement model name when no catalog key is matched.
    """


class Input(StrEnum):
    """
    Known model input and output modalities.
    """

    text = 'text'
    image = 'image'
    audio = 'audio'
    video = 'video'
    application_pdf = 'application/pdf'
    embedding = 'embedding'
    reranking = 'reranking'
    decision = 'decision'


class Output(StrEnum):
    """
    Known model input and output modalities.
    """

    text = 'text'
    image = 'image'
    audio = 'audio'
    video = 'video'
    application_pdf = 'application/pdf'
    embedding = 'embedding'
    reranking = 'reranking'
    decision = 'decision'


class Modalities(BaseModel):
    """
    Model input and output modalities.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    input: list[Input | constr(pattern=r'^(text|image|audio|video|application)\/[A-Za-z0-9.+-]+$')]
    """
    Modalities accepted by the model.
    """
    output: list[Output | constr(pattern=r'^(text|image|audio|video|application)\/[A-Za-z0-9.+-]+$')]
    """
    Modalities produced by the model.
    """


class Reasoning(BaseModel):
    """
    Reasoning support and controls when known.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    supported: Literal[False]
    """
    The model does not support explicit reasoning controls.
    """


class EffortEnum(StrEnum):
    """
    Normalized reasoning effort level.
    """

    none = 'none'
    minimal = 'minimal'
    low = 'low'
    medium = 'medium'
    high = 'high'
    xhigh = 'xhigh'
    max = 'max'
    default = 'default'


class DefaultEffort(StrEnum):
    """
    Default reasoning effort when no level is specified.
    """

    none = 'none'
    minimal = 'minimal'
    low = 'low'
    medium = 'medium'
    high = 'high'
    xhigh = 'xhigh'
    max = 'max'
    default = 'default'


class Budget(BaseModel):
    """
    Supported reasoning-token budget range.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    min: conint(ge=-9007199254740991, le=9007199254740991) | None = None
    """
    Minimum supported reasoning-token budget.
    """
    max: conint(ge=-9007199254740991, le=9007199254740991) | None = None
    """
    Maximum supported reasoning-token budget.
    """


class Reasoning1(BaseModel):
    """
    Reasoning support and controls when known.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    supported: Literal[True]
    """
    The model supports explicit reasoning controls.
    """
    effort: list[EffortEnum] | None = None
    """
    Supported reasoning effort levels.
    """
    default_effort: DefaultEffort | None = None
    """
    Default reasoning effort when no level is specified.
    """
    toggle: bool | None = None
    """
    Whether reasoning can be explicitly enabled or disabled.
    """
    budget: Budget | None = None
    """
    Supported reasoning-token budget range.
    """
    description: str | None = None
    """
    Combined Databricks description of reasoning behavior.
    """


class Capabilities(BaseModel):
    """
    Capabilities used to select the model for a workload.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    attachments: bool | None = None
    """
    Whether requests can include image, audio, video, or PDF attachments.
    """
    tools: bool | None = None
    """
    Whether the model supports tool or function calling.
    """
    structured_output: bool | None = None
    """
    Whether the model supports schema-constrained output.
    """
    temperature: bool | None = None
    """
    Whether the model supports temperature sampling.
    """
    interleaved_reasoning: bool | None = None
    """
    Whether reasoning content can be interleaved with the answer.
    """
    web_search: bool
    """
    Whether Databricks documents native web search support.
    """
    reasoning: Reasoning | Reasoning1 | None = None
    """
    Reasoning support and controls when known.
    """


class Limits(BaseModel):
    """
    Documented token limits.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    context: conint(ge=0, le=9007199254740991) | None = None
    """
    Maximum context window in tokens.
    """
    input: conint(ge=0, le=9007199254740991) | None = None
    """
    Maximum input length in tokens.
    """
    output: conint(ge=0, le=9007199254740991) | None = None
    """
    Maximum generated output length in tokens.
    """


class Status1(StrEnum):
    """
    Lifecycle state for this cloud-provider deployment.
    """

    active = 'active'
    preview = 'preview'
    alpha = 'alpha'
    beta = 'beta'
    legacy = 'legacy'
    deprecated = 'deprecated'
    retired = 'retired'


class ServingMode(StrEnum):
    """
    Databricks serving mode available for the model.
    """

    pay_per_token = 'pay_per_token'
    priority_pay_per_token = 'priority_pay_per_token'
    provisioned_throughput = 'provisioned_throughput'
    batch = 'batch'


class Availability(BaseModel):
    """
    Model availability on one Databricks cloud provider.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    status: Status1
    """
    Lifecycle state for this cloud-provider deployment.
    """
    serving_modes: list[ServingMode]
    """
    Serving modes documented or priced for this deployment.
    """
    details: str | None = None
    """
    Additional Databricks availability details.
    """


class Unit(StrEnum):
    """
    Quantity to which the rates apply.
    """

    per_million_tokens = 'per_million_tokens'
    per_hour = 'per_hour'
    per_hour_per_50_model_units = 'per_hour_per_50_model_units'


class Price(BaseModel):
    """
    Normalized Databricks price in one currency.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    unit: Unit
    """
    Quantity to which the rates apply.
    """
    rates: dict[constr(min_length=1), confloat(ge=0.0)]
    """
    Rates keyed by billing dimension.
    """


class AveragePrice(BaseModel):
    """
    Normalized Databricks price in one currency.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    unit: Unit
    """
    Quantity to which the rates apply.
    """
    rates: dict[constr(min_length=1), confloat(ge=0.0)]
    """
    Rates keyed by billing dimension.
    """


class Kind(StrEnum):
    """
    Known Databricks documentation notice kinds.
    """

    note = 'note'
    important = 'important'
    warning = 'warning'
    tip = 'tip'
    caution = 'caution'
    info = 'info'


class Notice(BaseModel):
    """
    Important Databricks documentation notice.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    kind: Kind | constr(min_length=1)
    """
    Documentation notice kind.
    """
    title: str | None = None
    """
    Notice title when it adds information beyond the kind.
    """
    text: str
    """
    Deduplicated notice text.
    """


class ReasoningEffort(StrEnum):
    """
    Reasoning effort used by the evaluated variant.
    """

    none = 'none'
    minimal = 'minimal'
    low = 'low'
    medium = 'medium'
    high = 'high'
    xhigh = 'xhigh'
    max = 'max'
    default = 'default'


class ReasoningMode(StrEnum):
    """
    Reasoning execution mode used by the evaluated variant.
    """

    auto = 'auto'
    thinking = 'thinking'


class Variant(BaseModel):
    """
    Evaluated model variant when it differs from the base model.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    reasoning: bool | None = None
    """
    Whether the evaluated variant used reasoning.
    """
    reasoning_effort: ReasoningEffort | None = None
    """
    Reasoning effort used by the evaluated variant.
    """
    reasoning_mode: ReasoningMode | None = None
    """
    Reasoning execution mode used by the evaluated variant.
    """
    harness: str | None = None
    """
    Agent or evaluation harness used for the result.
    """
    context: conint(le=9007199254740991, gt=0) | None = None
    """
    Context-window size used by the evaluated variant.
    """


class Rankings(BaseModel):
    """
    Competitive ranking based on human preference ratings.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    domain: str
    """
    Leaderboard domain or configuration.
    """
    category: str
    """
    Leaderboard category within the domain.
    """
    rank: conint(le=9007199254740991, gt=0)
    """
    One-based leaderboard rank.
    """
    published_at: date | None = None
    """
    Leaderboard publication date.
    """
    variant: Variant | None = None
    """
    Evaluated model variant when it differs from the base model.
    """
    metric: Literal['rating']
    """
    This ranking uses a preference rating.
    """
    rating: float
    """
    Central rating estimate.
    """
    lower: float
    """
    Lower confidence bound.
    """
    upper: float
    """
    Upper confidence bound.
    """
    variance: confloat(ge=0.0)
    """
    Estimated rating variance.
    """
    votes: conint(ge=0, le=9007199254740991)
    """
    Human preference votes used for the rating.
    """


class Variant1(BaseModel):
    """
    Evaluated model variant when it differs from the base model.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    reasoning: bool | None = None
    """
    Whether the evaluated variant used reasoning.
    """
    reasoning_effort: ReasoningEffort | None = None
    """
    Reasoning effort used by the evaluated variant.
    """
    reasoning_mode: ReasoningMode | None = None
    """
    Reasoning execution mode used by the evaluated variant.
    """
    harness: str | None = None
    """
    Agent or evaluation harness used for the result.
    """
    context: conint(le=9007199254740991, gt=0) | None = None
    """
    Context-window size used by the evaluated variant.
    """


class Rankings1(BaseModel):
    """
    Competitive ranking based on a scored evaluation.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    domain: str
    """
    Leaderboard domain or configuration.
    """
    category: str
    """
    Leaderboard category within the domain.
    """
    rank: conint(le=9007199254740991, gt=0)
    """
    One-based leaderboard rank.
    """
    published_at: date | None = None
    """
    Leaderboard publication date.
    """
    variant: Variant1 | None = None
    """
    Evaluated model variant when it differs from the base model.
    """
    metric: Literal['score']
    """
    This ranking uses an evaluation score.
    """
    score: float
    """
    Central score estimate.
    """
    lower: float
    """
    Lower confidence bound.
    """
    upper: float
    """
    Upper confidence bound.
    """
    observations: conint(ge=0, le=9007199254740991)
    """
    Observations used to estimate the score.
    """
    sessions: conint(ge=0, le=9007199254740991) | None
    """
    Evaluation sessions, or null when not reported.
    """


class Variant2(BaseModel):
    """
    Evaluated model variant when it differs from the base model.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    reasoning: bool | None = None
    """
    Whether the evaluated variant used reasoning.
    """
    reasoning_effort: ReasoningEffort | None = None
    """
    Reasoning effort used by the evaluated variant.
    """
    reasoning_mode: ReasoningMode | None = None
    """
    Reasoning execution mode used by the evaluated variant.
    """
    harness: str | None = None
    """
    Agent or evaluation harness used for the result.
    """
    context: conint(le=9007199254740991, gt=0) | None = None
    """
    Context-window size used by the evaluated variant.
    """


class Benchmark(BaseModel):
    """
    Task-suite benchmark result.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    name: str
    """
    Benchmark category or task-suite name.
    """
    rank: conint(le=9007199254740991, gt=0)
    """
    One-based benchmark rank.
    """
    score: float
    """
    Benchmark score.
    """
    task_count: conint(le=9007199254740991, gt=0)
    """
    Tasks represented by the benchmark score.
    """
    published_at: date | None = None
    """
    Benchmark publication date.
    """
    variant: Variant2 | None = None
    """
    Evaluated model variant when it differs from the base model.
    """


class CatalogModel(BaseModel):
    """
    Published statistics for one Databricks model.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    name: str
    """
    Canonical model name from Databricks documentation.
    """
    description: str
    """
    Consolidated description of the model and intended use.
    """
    aliases: list[str]
    """
    Alternative names and identifiers; excludes the catalog key.
    """
    type: Type
    """
    Normalized model type.
    """
    family: str | None = None
    """
    Model family used to group related versions.
    """
    publisher: str | None = None
    """
    Organization that develops or publishes the model.
    """
    license: str | None = None
    """
    Model license or upstream license classification.
    """
    open_weights: bool | None = None
    """
    Whether model weights are publicly available.
    """
    status: Status
    """
    Current normalized lifecycle state.
    """
    release_date: date | None = None
    """
    Model release date.
    """
    last_updated: date | None = None
    """
    Latest known model revision or metadata date.
    """
    knowledge_cutoff: date | None = None
    """
    Latest date covered by the model's stated training knowledge.
    """
    retirement: Retirement | None = None
    """
    Databricks retirement and replacement information.
    """
    modalities: Modalities
    """
    Model input and output modalities.
    """
    capabilities: Capabilities
    """
    Capabilities used to select the model for a workload.
    """
    limits: Limits | None = None
    """
    Documented token limits.
    """
    tasks: list[str]
    """
    High-level tasks documented for the model.
    """
    use_cases: list[str]
    """
    Example use cases documented for the model.
    """
    availability: dict[Literal['aws', 'azure', 'gcp'], Availability]
    """
    Availability keyed by Databricks cloud provider.
    """
    price: dict[Literal['aws', 'azure', 'gcp'], dict[Literal['DBU', 'USD'], Price]]
    """
    Average Databricks DBU and USD prices for each cloud provider.
    """
    average_price: dict[Literal['DBU', 'USD'], AveragePrice]
    """
    Average Databricks DBU and USD price across cloud providers and matched pricing variants.
    """
    notices: list[Notice]
    """
    Deduplicated Databricks documentation notices.
    """
    rankings: list[Rankings | Rankings1]
    """
    Competitive leaderboard rankings matched to the model.
    """
    benchmarks: list[Benchmark]
    """
    Task-suite benchmark results matched to the model.
    """


class ModelCatalog(BaseModel):
    """
    Published Databricks model catalog with identity, capabilities, availability, pricing, lifecycle, rankings, and benchmarks.
    """

    model_config = ConfigDict(
        extra='forbid',
    )
    schema_version: Literal[14]
    """
    Version of the published catalog contract.
    """
    updated_at: AwareDatetime
    """
    Latest source-fetch timestamp represented by the catalog.
    """
    models: dict[constr(min_length=1), CatalogModel]
    """
    Models keyed by Databricks serving endpoint or model service identifier.
    """


class CatalogModelRecord(CatalogModel):
    id: Annotated[str, Field(min_length=1)]


__all__ = [
    "CatalogModel",
    "CatalogModelRecord",
    "ModelCatalog",
    "Status",
    "Type",
]

